# SQS Handler

SQS Handler is a Python package that simplifies integration with AWS Simple Queue Service (SQS).

## Installation

```bash
pip install sqs-handler
